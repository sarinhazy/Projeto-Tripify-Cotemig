function cadastroCliente(e) {
  e.preventDefault();
  alert("Cadastro realizado com sucesso!");
  window.location.href = "pagina-viagens.html";
}