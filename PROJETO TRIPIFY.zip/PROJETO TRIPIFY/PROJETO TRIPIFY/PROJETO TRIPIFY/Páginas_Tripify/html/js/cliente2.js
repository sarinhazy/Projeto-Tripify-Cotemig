function loginCliente(e) {
  e.preventDefault();
  // Aqui futuramente você pode validar login real (ex: via API)
  window.location.href = "viagens.html";
}